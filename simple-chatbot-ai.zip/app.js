// Chatbot state
let conversationHistory = [];
let userName = null;
let messageCount = 0;
let detectedIntents = new Set();
let discussedTopics = new Set();

// Intent database with patterns and responses
const intents = {
    greetings: {
        patterns: [/\b(hello|hi|hey|greetings|wassup|howdy)\b/i],
        responses: [
            "Hello there! How can I help?",
            "Hi! Welcome! What can I assist you with?",
            "Hey! Good to see you. What's on your mind?",
            "Greetings! I'm here to chat and help."
        ],
        topic: "General Conversation"
    },
    farewell: {
        patterns: [/\b(bye|goodbye|see you|farewell|exit|quit|stop)\b/i],
        responses: [
            "Goodbye! Feel free to come back anytime!",
            "See you later! Have a great day!",
            "Bye! It was nice chatting with you!",
            "Farewell! Come back soon!"
        ],
        topic: "General Conversation"
    },
    who_are_you: {
        patterns: [/\b(who are you|what are you|what'?s your name|tell me about yourself)\b/i],
        responses: [
            "I'm a rule-based chatbot designed to help you understand NLP concepts!",
            "I'm an AI assistant built to demonstrate pattern matching and intent recognition.",
            "I'm a chatbot powered by predefined rules and pattern matching. Nice to meet you!"
        ],
        topic: "Chatbot Information"
    },
    capabilities: {
        patterns: [/\b(what can you do|help|capabilities|features|commands)\b/i],
        responses: [
            "I can answer questions, recognize your intent using pattern matching, remember your name, and have natural conversations! Try asking me anything.",
            "I'm capable of: Intent recognition, pattern matching, context awareness, and conversational responses. What would you like to know?"
        ],
        topic: "Chatbot Information"
    },
    how_are_you: {
        patterns: [/\b(how are you|how'?s it going|what'?s up|how are things)\b/i],
        responses: [
            "I'm doing great, thanks for asking!",
            "I'm functioning perfectly! How are you doing?",
            "I'm always ready to chat and learn!"
        ],
        topic: "Small Talk"
    },
    thanks: {
        patterns: [/\b(thank you|thanks|appreciate|thanks a lot|thank you so much)\b/i],
        responses: [
            "You're welcome!",
            "Happy to help!",
            "Anytime! Glad I could assist.",
            "My pleasure!"
        ],
        topic: "General Conversation"
    },
    nlp_explanation: {
        patterns: [/\b(what is nlp|explain nlp|natural language processing|nlp meaning)\b/i],
        responses: [
            "NLP stands for Natural Language Processing. It's a branch of AI that helps computers understand, interpret, and respond to human language in a meaningful way.",
            "Natural Language Processing (NLP) enables computers to process and understand human language. It involves tokenization, intent recognition, entity extraction, and response generation."
        ],
        topic: "NLP Basics"
    },
    pattern_matching: {
        patterns: [/\b(pattern matching|how do you work|how do you understand|how does this work)\b/i],
        responses: [
            "I use pattern matching! I compare your input against predefined patterns using regular expressions. When a match is found, I select an appropriate response.",
            "I work by matching your input against patterns I know. If your message contains keywords from my pattern database, I recognize the intent and respond accordingly."
        ],
        topic: "Pattern Matching"
    },
    time_query: {
        patterns: [/\b(what time is it|current time|tell me the time|time)\b/i],
        responses: [
            "It's {time} right now.",
            "The current time is {time}."
        ],
        topic: "Time Query",
        dynamic: true
    },
    name_introduction: {
        patterns: [/\b(my name is|i'?m |call me|i am )([a-z]+)\b/i],
        responses: [
            "Nice to meet you, {name}! What can I help you with?",
            "Great to know you, {name}! Feel free to ask me anything.",
            "Hello {name}! Pleased to make your acquaintance!"
        ],
        topic: "Personal Information",
        extract: true
    },
    polite: {
        patterns: [/\b(please|could you|would you|can you)\b/i],
        responses: [
            "Of course! I'm here to help.",
            "Sure thing!",
            "Absolutely!"
        ],
        topic: "General Conversation"
    }
};

// Default responses
const defaultResponses = [
    "That's interesting! I'm still learning. Could you try asking differently?",
    "I'm not sure I understand. Can you rephrase that?",
    "Hmm, that's a new one! Try asking me about NLP, pattern matching, or my capabilities!",
    "I'm still developing my understanding. Any other questions?"
];

// Initialize chatbot
function init() {
    updateStats();
    document.getElementById('userInput').focus();
}

// Handle key press in input
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

// Send quick message
function sendQuickMessage(message) {
    document.getElementById('userInput').value = message;
    sendMessage();
}

// Send message
function sendMessage() {
    const input = document.getElementById('userInput');
    const message = input.value.trim();
    
    if (message === '') return;
    
    // Add user message to chat
    addMessage('user', message);
    
    // Clear input
    input.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Process message and get response
    setTimeout(() => {
        const response = processMessage(message);
        hideTypingIndicator();
        addMessage('bot', response.text, response.intent, response.confidence);
        
        // Update stats
        messageCount += 2; // User + Bot
        if (response.intent !== 'default') {
            detectedIntents.add(response.intent);
        }
        if (response.topic) {
            discussedTopics.add(response.topic);
        }
        updateStats();
    }, 800);
}

// Process user message
function processMessage(message) {
    // Check for name extraction first
    const nameMatch = message.match(/\b(my name is|i'?m |call me|i am )([a-z]+)\b/i);
    if (nameMatch && nameMatch[2]) {
        userName = nameMatch[2].charAt(0).toUpperCase() + nameMatch[2].slice(1).toLowerCase();
    }
    
    // Try to match intent
    for (const [intentName, intentData] of Object.entries(intents)) {
        for (const pattern of intentData.patterns) {
            if (pattern.test(message)) {
                let response = intentData.responses[Math.floor(Math.random() * intentData.responses.length)];
                
                // Handle dynamic responses
                if (intentData.dynamic) {
                    if (intentName === 'time_query') {
                        const now = new Date();
                        const timeString = now.toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit',
                            hour12: true 
                        });
                        response = response.replace('{time}', timeString);
                    }
                }
                
                // Handle name extraction
                if (intentData.extract && userName) {
                    response = response.replace('{name}', userName);
                }
                
                // Use user's name in greeting if known
                if (intentName === 'greetings' && userName) {
                    response = `Hello ${userName}! ` + response.split('!')[1];
                }
                
                // Calculate confidence based on pattern strength
                const confidence = calculateConfidence(message, pattern);
                
                return {
                    text: response,
                    intent: intentName.replace(/_/g, ' '),
                    confidence: confidence,
                    topic: intentData.topic
                };
            }
        }
    }
    
    // Default response
    return {
        text: defaultResponses[Math.floor(Math.random() * defaultResponses.length)],
        intent: 'default',
        confidence: 'low',
        topic: null
    };
}

// Calculate confidence score
function calculateConfidence(message, pattern) {
    const match = message.match(pattern);
    if (!match) return 'low';
    
    const matchedLength = match[0].length;
    const messageLength = message.length;
    const ratio = matchedLength / messageLength;
    
    if (ratio > 0.5) return 'high';
    if (ratio > 0.2) return 'medium';
    return 'low';
}

// Add message to chat
function addMessage(sender, text, intent = null, confidence = null) {
    const messagesContainer = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = sender === 'bot' ? '🤖' : '👤';
    
    const content = document.createElement('div');
    content.className = 'message-content';
    
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.textContent = text;
    
    content.appendChild(bubble);
    
    // Add metadata for bot messages with educational info
    if (sender === 'bot' && intent && intent !== 'default') {
        const meta = document.createElement('div');
        meta.className = 'message-meta';
        
        const intentBadge = document.createElement('span');
        intentBadge.className = 'intent-badge';
        intentBadge.textContent = `Intent: ${intent}`;
        
        const confidenceSpan = document.createElement('span');
        confidenceSpan.className = `confidence ${confidence}`;
        confidenceSpan.textContent = `Confidence: ${confidence}`;
        
        meta.appendChild(intentBadge);
        meta.appendChild(confidenceSpan);
        content.appendChild(meta);
    }
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    
    messagesContainer.appendChild(messageDiv);
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Add to history
    conversationHistory.push({ sender, text, intent, confidence });
}

// Show typing indicator
function showTypingIndicator() {
    const messagesContainer = document.getElementById('chatMessages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot';
    typingDiv.id = 'typingIndicator';
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = '🤖';
    
    const content = document.createElement('div');
    content.className = 'message-content';
    
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble typing-indicator';
    bubble.innerHTML = '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';
    
    content.appendChild(bubble);
    typingDiv.appendChild(avatar);
    typingDiv.appendChild(content);
    
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Hide typing indicator
function hideTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) {
        indicator.remove();
    }
}

// Clear chat
function clearChat() {
    const messagesContainer = document.getElementById('chatMessages');
    messagesContainer.innerHTML = '';
    
    // Add welcome message back
    addMessage('bot', "Hello! I'm a rule-based chatbot designed to help you understand NLP concepts. I use pattern matching to recognize your intent and respond accordingly. Try asking me something!");
    
    // Reset stats
    conversationHistory = [];
    userName = null;
    messageCount = 0;
    detectedIntents = new Set();
    discussedTopics = new Set();
    updateStats();
}

// Update stats display
function updateStats() {
    document.getElementById('messageCount').textContent = messageCount;
    document.getElementById('intentCount').textContent = detectedIntents.size;
    
    // Update topics list
    const topicsList = document.getElementById('topicsList');
    if (discussedTopics.size === 0) {
        topicsList.innerHTML = '<div class="topic-item" style="opacity: 0.5;">Start chatting to see topics...</div>';
    } else {
        topicsList.innerHTML = '';
        discussedTopics.forEach(topic => {
            const topicItem = document.createElement('div');
            topicItem.className = 'topic-item';
            topicItem.textContent = topic;
            topicsList.appendChild(topicItem);
        });
    }
}

// Initialize on load
init();