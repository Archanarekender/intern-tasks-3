// Application State
let appState = {
  currentUser: null,
  users: [],
  courses: [],
  enrollments: [],
  attendance: [],
  currentView: null
};

// Initialize sample data
function initializeSampleData() {
  // Sample Users
  appState.users = [
    {
      id: "STU001",
      name: "Aisha Patel",
      email: "aisha@uni.edu",
      password: "demo123",
      role: "student",
      department: "Computer Science"
    },
    {
      id: "STU002",
      name: "Raj Kumar",
      email: "raj@uni.edu",
      password: "demo123",
      role: "student",
      department: "Computer Science"
    },
    {
      id: "STU003",
      name: "Emma Johnson",
      email: "emma@uni.edu",
      password: "demo123",
      role: "student",
      department: "Engineering"
    },
    {
      id: "STU004",
      name: "Chen Wei",
      email: "chen@uni.edu",
      password: "demo123",
      role: "student",
      department: "Mathematics"
    },
    {
      id: "STU005",
      name: "Sofia Garcia",
      email: "sofia@uni.edu",
      password: "demo123",
      role: "student",
      department: "Physics"
    },
    {
      id: "PROF001",
      name: "Dr. Robert Smith",
      email: "prof1@uni.edu",
      password: "demo123",
      role: "instructor",
      department: "Computer Science"
    },
    {
      id: "PROF002",
      name: "Dr. Maria Garcia",
      email: "prof2@uni.edu",
      password: "demo123",
      role: "instructor",
      department: "Mathematics"
    }
  ];

  // Sample Courses
  appState.courses = [
    {
      id: "CS101",
      code: "CS101",
      name: "Introduction to Computer Science",
      instructor: "PROF001",
      semester: "Fall 2025",
      schedule: "Mon/Wed 10:00 AM",
      location: "Room 101",
      capacity: 40
    },
    {
      id: "CS102",
      code: "CS102",
      name: "Data Structures",
      instructor: "PROF001",
      semester: "Fall 2025",
      schedule: "Tue/Thu 2:00 PM",
      location: "Room 205",
      capacity: 35
    },
    {
      id: "CS103",
      code: "CS103",
      name: "Web Development",
      instructor: "PROF001",
      semester: "Fall 2025",
      schedule: "Fri 1:00 PM",
      location: "Lab 301",
      capacity: 30
    },
    {
      id: "MATH101",
      code: "MATH101",
      name: "Calculus I",
      instructor: "PROF002",
      semester: "Fall 2025",
      schedule: "Mon/Wed/Fri 9:00 AM",
      location: "Room 310",
      capacity: 45
    },
    {
      id: "MATH102",
      code: "MATH102",
      name: "Linear Algebra",
      instructor: "PROF002",
      semester: "Fall 2025",
      schedule: "Tue/Thu 11:00 AM",
      location: "Room 320",
      capacity: 40
    },
    {
      id: "PHYS101",
      code: "PHYS101",
      name: "Physics I",
      instructor: "PROF001",
      semester: "Fall 2025",
      schedule: "Mon/Wed 1:00 PM",
      location: "Lab 101",
      capacity: 35
    },
    {
      id: "PHYS102",
      code: "PHYS102",
      name: "Physics II",
      instructor: "PROF002",
      semester: "Fall 2025",
      schedule: "Tue/Thu 3:00 PM",
      location: "Lab 102",
      capacity: 30
    },
    {
      id: "ENG101",
      code: "ENG101",
      name: "Technical Writing",
      instructor: "PROF002",
      semester: "Fall 2025",
      schedule: "Fri 10:00 AM",
      location: "Room 405",
      capacity: 25
    }
  ];

  // Sample Enrollments
  appState.enrollments = [
    { studentId: "STU001", courseId: "CS101" },
    { studentId: "STU001", courseId: "CS102" },
    { studentId: "STU001", courseId: "MATH101" },
    { studentId: "STU002", courseId: "CS101" },
    { studentId: "STU002", courseId: "CS103" },
    { studentId: "STU002", courseId: "MATH101" },
    { studentId: "STU003", courseId: "ENG101" },
    { studentId: "STU003", courseId: "CS102" },
    { studentId: "STU003", courseId: "PHYS101" },
    { studentId: "STU004", courseId: "MATH101" },
    { studentId: "STU004", courseId: "MATH102" },
    { studentId: "STU004", courseId: "CS101" },
    { studentId: "STU005", courseId: "PHYS101" },
    { studentId: "STU005", courseId: "PHYS102" },
    { studentId: "STU005", courseId: "MATH102" }
  ];

  // Generate sample attendance records
  const dates = generatePastDates(15);
  appState.attendance = [];
  let attendanceId = 1;

  appState.enrollments.forEach(enrollment => {
    dates.forEach(date => {
      const randomStatus = Math.random();
      let status = "Present";
      if (randomStatus < 0.1) status = "Absent";
      else if (randomStatus < 0.15) status = "Leave";

      appState.attendance.push({
        id: `ATT${String(attendanceId).padStart(4, '0')}`,
        courseId: enrollment.courseId,
        studentId: enrollment.studentId,
        date: date,
        status: status,
        markedBy: getCourseInstructor(enrollment.courseId),
        timestamp: new Date(date).toISOString()
      });
      attendanceId++;
    });
  });
}

// Helper: Generate past dates
function generatePastDates(count) {
  const dates = [];
  const today = new Date();
  for (let i = count - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i * 2);
    dates.push(date.toISOString().split('T')[0]);
  }
  return dates;
}

// Helper: Get course instructor
function getCourseInstructor(courseId) {
  const course = appState.courses.find(c => c.id === courseId);
  return course ? course.instructor : null;
}

// Authentication Functions
function validateEmail(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

function validatePassword(password) {
  return password.length >= 6;
}

function login(email, password) {
  const user = appState.users.find(u => u.email === email && u.password === password);
  if (user) {
    appState.currentUser = user;
    return { success: true, user };
  }
  return { success: false, message: "Invalid email or password" };
}

function register(name, email, password, role, department) {
  if (!validateEmail(email)) {
    return { success: false, message: "Invalid email format" };
  }
  if (!validatePassword(password)) {
    return { success: false, message: "Password must be at least 6 characters" };
  }
  if (appState.users.find(u => u.email === email)) {
    return { success: false, message: "Email already registered" };
  }

  const newUser = {
    id: generateUserId(role),
    name,
    email,
    password,
    role,
    department
  };

  appState.users.push(newUser);
  appState.currentUser = newUser;
  return { success: true, user: newUser };
}

function generateUserId(role) {
  const prefix = role === "student" ? "STU" : "PROF";
  const count = appState.users.filter(u => u.role === role).length + 1;
  return `${prefix}${String(count).padStart(3, '0')}`;
}

function logout() {
  appState.currentUser = null;
  showView('authView');
}

// View Management
function showView(viewId) {
  document.querySelectorAll('.auth-container, .dashboard-layout').forEach(el => {
    el.classList.add('hidden');
  });
  document.getElementById(viewId).classList.remove('hidden');
}

function showDashboard(role) {
  if (role === 'student') {
    showView('studentView');
    renderStudentDashboard();
  } else if (role === 'instructor') {
    showView('instructorView');
    renderInstructorDashboard();
  }
}

// Student Functions
function getStudentCourses(studentId) {
  const enrolledCourseIds = appState.enrollments
    .filter(e => e.studentId === studentId)
    .map(e => e.courseId);
  return appState.courses.filter(c => enrolledCourseIds.includes(c.id));
}

function getStudentAttendance(studentId, courseId = null) {
  let records = appState.attendance.filter(a => a.studentId === studentId);
  if (courseId) {
    records = records.filter(a => a.courseId === courseId);
  }
  return records;
}

function calculateAttendancePercentage(studentId, courseId = null) {
  const records = getStudentAttendance(studentId, courseId);
  if (records.length === 0) return 0;
  const presentCount = records.filter(r => r.status === "Present").length;
  return Math.round((presentCount / records.length) * 100);
}

function getAttendanceClass(percentage) {
  if (percentage >= 75) return 'high';
  if (percentage >= 60) return 'medium';
  return 'low';
}

// Instructor Functions
function getInstructorCourses(instructorId) {
  return appState.courses.filter(c => c.instructor === instructorId);
}

function getCourseStudents(courseId) {
  const enrolledStudentIds = appState.enrollments
    .filter(e => e.courseId === courseId)
    .map(e => e.studentId);
  return appState.users.filter(u => enrolledStudentIds.includes(u.id));
}

function getCourseAttendance(courseId, date = null) {
  let records = appState.attendance.filter(a => a.courseId === courseId);
  if (date) {
    records = records.filter(a => a.date === date);
  }
  return records;
}

function markAttendance(courseId, studentId, date, status) {
  const existing = appState.attendance.find(
    a => a.courseId === courseId && a.studentId === studentId && a.date === date
  );

  if (existing) {
    existing.status = status;
    existing.timestamp = new Date().toISOString();
    existing.markedBy = appState.currentUser.id;
  } else {
    appState.attendance.push({
      id: `ATT${String(appState.attendance.length + 1).padStart(4, '0')}`,
      courseId,
      studentId,
      date,
      status,
      markedBy: appState.currentUser.id,
      timestamp: new Date().toISOString()
    });
  }
}

function createCourse(courseData) {
  const newCourse = {
    id: courseData.code,
    code: courseData.code,
    name: courseData.name,
    instructor: appState.currentUser.id,
    semester: courseData.semester,
    schedule: courseData.schedule,
    location: courseData.location,
    capacity: parseInt(courseData.capacity)
  };
  appState.courses.push(newCourse);
  return newCourse;
}

function deleteCourse(courseId) {
  appState.courses = appState.courses.filter(c => c.id !== courseId);
  appState.enrollments = appState.enrollments.filter(e => e.courseId !== courseId);
  appState.attendance = appState.attendance.filter(a => a.courseId !== courseId);
}

// UI Rendering Functions
function renderStudentDashboard() {
  const content = document.getElementById('studentContent');
  const user = appState.currentUser;
  
  // Update user info
  document.getElementById('studentName').textContent = user.name;
  document.getElementById('studentAvatar').textContent = user.name.charAt(0);
  document.getElementById('studentPageTitle').textContent = 'Dashboard';

  const courses = getStudentCourses(user.id);
  const totalAttendance = getStudentAttendance(user.id);
  const presentCount = totalAttendance.filter(a => a.status === "Present").length;
  const overallPercentage = calculateAttendancePercentage(user.id);

  content.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Enrolled Courses</div>
        <div class="stat-value">${courses.length}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Overall Attendance</div>
        <div class="stat-value">${overallPercentage}%</div>
        <div class="stat-change">📊 ${presentCount}/${totalAttendance.length} classes</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Classes This Week</div>
        <div class="stat-value">${Math.min(courses.length * 2, 12)}</div>
      </div>
    </div>

    <div class="section-header">
      <h2 class="section-title">My Courses</h2>
    </div>

    <div class="courses-grid">
      ${courses.map(course => {
        const instructor = appState.users.find(u => u.id === course.instructor);
        const attendance = calculateAttendancePercentage(user.id, course.id);
        const attendanceClass = getAttendanceClass(attendance);
        const records = getStudentAttendance(user.id, course.id);
        const present = records.filter(r => r.status === "Present").length;

        return `
          <div class="course-card" onclick="showStudentCourseDetail('${course.id}')">
            <div class="course-header">
              <div class="course-code">${course.code}</div>
            </div>
            <div class="course-name">${course.name}</div>
            <div class="course-info">👨‍🏫 ${instructor ? instructor.name : 'Unknown'}</div>
            <div class="course-info">📅 ${course.schedule}</div>
            <div class="course-info">📍 ${course.location}</div>
            <div class="attendance-bar">
              <div class="attendance-label">
                <span>Attendance</span>
                <span>${attendance}%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill ${attendanceClass}" style="width: ${attendance}%"></div>
              </div>
              <div class="course-info" style="margin-top: var(--space-8);">
                ${present}/${records.length} classes attended
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function showStudentCourseDetail(courseId) {
  const content = document.getElementById('studentContent');
  const user = appState.currentUser;
  const course = appState.courses.find(c => c.id === courseId);
  const instructor = appState.users.find(u => u.id === course.instructor);
  const records = getStudentAttendance(user.id, courseId);
  const attendance = calculateAttendancePercentage(user.id, courseId);
  const attendanceClass = getAttendanceClass(attendance);
  const present = records.filter(r => r.status === "Present").length;

  document.getElementById('studentPageTitle').textContent = course.name;

  content.innerHTML = `
    <button class="btn btn-secondary" onclick="renderStudentDashboard()" style="margin-bottom: var(--space-24);">
      ← Back to Dashboard
    </button>

    <div class="stat-card" style="margin-bottom: var(--space-24);">
      <div style="display: flex; justify-content: space-between; align-items: start;">
        <div>
          <div class="course-code" style="margin-bottom: var(--space-12);">${course.code}</div>
          <h2 style="font-size: var(--font-size-2xl); margin-bottom: var(--space-12);">${course.name}</h2>
          <div class="course-info" style="margin-bottom: var(--space-4);">👨‍🏫 Instructor: ${instructor.name}</div>
          <div class="course-info" style="margin-bottom: var(--space-4);">📅 Schedule: ${course.schedule}</div>
          <div class="course-info" style="margin-bottom: var(--space-4);">📍 Location: ${course.location}</div>
          <div class="course-info">📚 Semester: ${course.semester}</div>
        </div>
        <div style="text-align: right;">
          <div class="stat-label">Attendance</div>
          <div class="stat-value" style="color: var(--color-${attendanceClass === 'high' ? 'success' : attendanceClass === 'medium' ? 'warning' : 'error'});">${attendance}%</div>
          <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary);">${present}/${records.length} classes</div>
        </div>
      </div>
    </div>

    <div class="section-header">
      <h2 class="section-title">Attendance History</h2>
    </div>

    <div class="table-container">
      <div class="table-scroll">
        <table class="table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Day</th>
              <th>Status</th>
              <th>Marked At</th>
            </tr>
          </thead>
          <tbody>
            ${records.sort((a, b) => new Date(b.date) - new Date(a.date)).map(record => {
              const date = new Date(record.date);
              const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
              const dateStr = date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
              const timeStr = new Date(record.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
              
              return `
                <tr>
                  <td>${dateStr}</td>
                  <td>${dayName}</td>
                  <td>
                    <span class="status status--${record.status === 'Present' ? 'success' : record.status === 'Leave' ? 'warning' : 'error'}">
                      ${record.status === 'Present' ? '✓' : record.status === 'Leave' ? '📋' : '✗'} ${record.status}
                    </span>
                  </td>
                  <td>${timeStr}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderStudentCourses() {
  const content = document.getElementById('studentContent');
  const user = appState.currentUser;
  const courses = getStudentCourses(user.id);

  document.getElementById('studentPageTitle').textContent = 'My Courses';

  content.innerHTML = `
    <div class="section-header">
      <h2 class="section-title">Enrolled Courses (${courses.length})</h2>
    </div>

    <div class="courses-grid">
      ${courses.map(course => {
        const instructor = appState.users.find(u => u.id === course.instructor);
        const attendance = calculateAttendancePercentage(user.id, course.id);
        const attendanceClass = getAttendanceClass(attendance);
        const records = getStudentAttendance(user.id, course.id);
        const present = records.filter(r => r.status === "Present").length;

        return `
          <div class="course-card" onclick="showStudentCourseDetail('${course.id}')">
            <div class="course-header">
              <div class="course-code">${course.code}</div>
            </div>
            <div class="course-name">${course.name}</div>
            <div class="course-info">👨‍🏫 ${instructor ? instructor.name : 'Unknown'}</div>
            <div class="course-info">📅 ${course.schedule}</div>
            <div class="course-info">📍 ${course.location}</div>
            <div class="attendance-bar">
              <div class="attendance-label">
                <span>Attendance</span>
                <span>${attendance}%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill ${attendanceClass}" style="width: ${attendance}%"></div>
              </div>
              <div class="course-info" style="margin-top: var(--space-8);">
                ${present}/${records.length} classes attended
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderStudentAttendance() {
  const content = document.getElementById('studentContent');
  const user = appState.currentUser;
  const courses = getStudentCourses(user.id);

  document.getElementById('studentPageTitle').textContent = 'Attendance Records';

  content.innerHTML = `
    <div class="section-header">
      <h2 class="section-title">All Attendance Records</h2>
    </div>

    ${courses.map(course => {
      const records = getStudentAttendance(user.id, course.id);
      const attendance = calculateAttendancePercentage(user.id, course.id);
      const present = records.filter(r => r.status === "Present").length;

      return `
        <div style="margin-bottom: var(--space-32);">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-16);">
            <div>
              <h3 style="font-size: var(--font-size-xl); font-weight: var(--font-weight-semibold);">
                ${course.code} - ${course.name}
              </h3>
              <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-top: var(--space-4);">
                ${present}/${records.length} classes attended (${attendance}%)
              </div>
            </div>
            <button class="btn btn-primary btn-sm" onclick="showStudentCourseDetail('${course.id}')">
              View Details
            </button>
          </div>

          <div class="table-container">
            <div class="table-scroll">
              <table class="table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Time</th>
                  </tr>
                </thead>
                <tbody>
                  ${records.slice(0, 5).sort((a, b) => new Date(b.date) - new Date(a.date)).map(record => {
                    const date = new Date(record.date);
                    const dateStr = date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
                    const timeStr = new Date(record.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                    
                    return `
                      <tr>
                        <td>${dateStr}</td>
                        <td>
                          <span class="status status--${record.status === 'Present' ? 'success' : record.status === 'Leave' ? 'warning' : 'error'}">
                            ${record.status === 'Present' ? '✓' : record.status === 'Leave' ? '📋' : '✗'} ${record.status}
                          </span>
                        </td>
                        <td>${timeStr}</td>
                      </tr>
                    `;
                  }).join('')}
                  ${records.length > 5 ? `
                    <tr>
                      <td colspan="3" style="text-align: center; color: var(--color-text-secondary);">
                        <a class="auth-link" onclick="showStudentCourseDetail('${course.id}')">View all ${records.length} records</a>
                      </td>
                    </tr>
                  ` : ''}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      `;
    }).join('')}
  `;
}

function renderStudentProfile() {
  const content = document.getElementById('studentContent');
  const user = appState.currentUser;
  const courses = getStudentCourses(user.id);
  const totalAttendance = getStudentAttendance(user.id);
  const overallPercentage = calculateAttendancePercentage(user.id);

  document.getElementById('studentPageTitle').textContent = 'Profile';

  content.innerHTML = `
    <div class="stat-card">
      <div style="display: flex; gap: var(--space-24);">
        <div class="user-avatar" style="width: 80px; height: 80px; font-size: var(--font-size-3xl);">
          ${user.name.charAt(0)}
        </div>
        <div style="flex: 1;">
          <h2 style="font-size: var(--font-size-2xl); margin-bottom: var(--space-8);">${user.name}</h2>
          <div class="course-info" style="margin-bottom: var(--space-4);">🆔 Student ID: ${user.id}</div>
          <div class="course-info" style="margin-bottom: var(--space-4);">📧 Email: ${user.email}</div>
          <div class="course-info" style="margin-bottom: var(--space-4);">🏛️ Department: ${user.department}</div>
          <div class="course-info">📚 Enrolled Courses: ${courses.length}</div>
        </div>
      </div>
    </div>

    <div class="stats-grid" style="margin-top: var(--space-24);">
      <div class="stat-card">
        <div class="stat-label">Overall Attendance</div>
        <div class="stat-value">${overallPercentage}%</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Classes Attended</div>
        <div class="stat-value">${totalAttendance.filter(a => a.status === 'Present').length}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Classes</div>
        <div class="stat-value">${totalAttendance.length}</div>
      </div>
    </div>
  `;
}

function renderInstructorDashboard() {
  const content = document.getElementById('instructorContent');
  const user = appState.currentUser;
  
  document.getElementById('instructorName').textContent = user.name;
  document.getElementById('instructorAvatar').textContent = user.name.charAt(0);
  document.getElementById('instructorPageTitle').textContent = 'Dashboard';

  const courses = getInstructorCourses(user.id);
  let totalStudents = 0;
  let totalClasses = 0;
  let totalPresent = 0;

  courses.forEach(course => {
    const students = getCourseStudents(course.id);
    totalStudents += students.length;
    const attendance = getCourseAttendance(course.id);
    totalClasses += attendance.length;
    totalPresent += attendance.filter(a => a.status === 'Present').length;
  });

  const avgAttendance = totalClasses > 0 ? Math.round((totalPresent / totalClasses) * 100) : 0;

  content.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Courses Teaching</div>
        <div class="stat-value">${courses.length}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Students</div>
        <div class="stat-value">${totalStudents}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Average Attendance</div>
        <div class="stat-value">${avgAttendance}%</div>
      </div>
    </div>

    <div class="section-header">
      <h2 class="section-title">My Courses</h2>
      <button class="btn btn-primary" onclick="showCreateCourseModal()">
        ➕ Create Course
      </button>
    </div>

    <div class="courses-grid">
      ${courses.map(course => {
        const students = getCourseStudents(course.id);
        const attendance = getCourseAttendance(course.id);
        const present = attendance.filter(a => a.status === 'Present').length;
        const courseAttendance = attendance.length > 0 ? Math.round((present / attendance.length) * 100) : 0;
        const attendanceClass = getAttendanceClass(courseAttendance);

        return `
          <div class="course-card" onclick="showInstructorCourseDetail('${course.id}')">
            <div class="course-header">
              <div class="course-code">${course.code}</div>
            </div>
            <div class="course-name">${course.name}</div>
            <div class="course-info">👥 ${students.length} students enrolled</div>
            <div class="course-info">📅 ${course.schedule}</div>
            <div class="course-info">📍 ${course.location}</div>
            <div class="attendance-bar">
              <div class="attendance-label">
                <span>Average Attendance</span>
                <span>${courseAttendance}%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill ${attendanceClass}" style="width: ${courseAttendance}%"></div>
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function showInstructorCourseDetail(courseId) {
  const content = document.getElementById('instructorContent');
  const course = appState.courses.find(c => c.id === courseId);
  const students = getCourseStudents(courseId);

  document.getElementById('instructorPageTitle').textContent = course.name;

  content.innerHTML = `
    <button class="btn btn-secondary" onclick="renderInstructorDashboard()" style="margin-bottom: var(--space-24);">
      ← Back to Dashboard
    </button>

    <div class="stat-card" style="margin-bottom: var(--space-24);">
      <div style="display: flex; justify-content: space-between; align-items: start;">
        <div>
          <div class="course-code" style="margin-bottom: var(--space-12);">${course.code}</div>
          <h2 style="font-size: var(--font-size-2xl); margin-bottom: var(--space-12);">${course.name}</h2>
          <div class="course-info" style="margin-bottom: var(--space-4);">📅 Schedule: ${course.schedule}</div>
          <div class="course-info" style="margin-bottom: var(--space-4);">📍 Location: ${course.location}</div>
          <div class="course-info" style="margin-bottom: var(--space-4);">📚 Semester: ${course.semester}</div>
          <div class="course-info">👥 Enrolled: ${students.length}/${course.capacity}</div>
        </div>
        <div style="display: flex; gap: var(--space-12);">
          <button class="btn btn-primary" onclick="showMarkAttendanceModal('${courseId}')">
            ✓ Mark Attendance
          </button>
          <button class="btn btn-secondary" onclick="deleteCourseConfirm('${courseId}')">
            🗑️ Delete
          </button>
        </div>
      </div>
    </div>

    <div class="section-header">
      <h2 class="section-title">Student Roster</h2>
    </div>

    <div class="table-container">
      <div class="table-scroll">
        <table class="table">
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Name</th>
              <th>Department</th>
              <th>Classes Held</th>
              <th>Attended</th>
              <th>Attendance %</th>
            </tr>
          </thead>
          <tbody>
            ${students.map(student => {
              const records = getStudentAttendance(student.id, courseId);
              const present = records.filter(r => r.status === 'Present').length;
              const percentage = calculateAttendancePercentage(student.id, courseId);
              const attendanceClass = getAttendanceClass(percentage);

              return `
                <tr>
                  <td>${student.id}</td>
                  <td>${student.name}</td>
                  <td>${student.department}</td>
                  <td>${records.length}</td>
                  <td>${present}</td>
                  <td>
                    <span class="status status--${attendanceClass === 'high' ? 'success' : attendanceClass === 'medium' ? 'warning' : 'error'}">
                      ${percentage}%
                    </span>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderInstructorCourses() {
  const content = document.getElementById('instructorContent');
  const user = appState.currentUser;
  const courses = getInstructorCourses(user.id);

  document.getElementById('instructorPageTitle').textContent = 'My Courses';

  content.innerHTML = `
    <div class="section-header">
      <h2 class="section-title">Teaching Courses (${courses.length})</h2>
      <button class="btn btn-primary" onclick="showCreateCourseModal()">
        ➕ Create Course
      </button>
    </div>

    <div class="courses-grid">
      ${courses.map(course => {
        const students = getCourseStudents(course.id);
        const attendance = getCourseAttendance(course.id);
        const present = attendance.filter(a => a.status === 'Present').length;
        const courseAttendance = attendance.length > 0 ? Math.round((present / attendance.length) * 100) : 0;
        const attendanceClass = getAttendanceClass(courseAttendance);

        return `
          <div class="course-card" onclick="showInstructorCourseDetail('${course.id}')">
            <div class="course-header">
              <div class="course-code">${course.code}</div>
            </div>
            <div class="course-name">${course.name}</div>
            <div class="course-info">👥 ${students.length} students enrolled</div>
            <div class="course-info">📅 ${course.schedule}</div>
            <div class="course-info">📍 ${course.location}</div>
            <div class="attendance-bar">
              <div class="attendance-label">
                <span>Average Attendance</span>
                <span>${courseAttendance}%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill ${attendanceClass}" style="width: ${courseAttendance}%"></div>
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderInstructorAttendance() {
  const content = document.getElementById('instructorContent');
  const user = appState.currentUser;
  const courses = getInstructorCourses(user.id);

  document.getElementById('instructorPageTitle').textContent = 'Mark Attendance';

  content.innerHTML = `
    <div class="section-header">
      <h2 class="section-title">Select Course to Mark Attendance</h2>
    </div>

    <div class="courses-grid">
      ${courses.map(course => {
        const students = getCourseStudents(course.id);
        return `
          <div class="course-card" onclick="showMarkAttendanceModal('${course.id}')">
            <div class="course-header">
              <div class="course-code">${course.code}</div>
            </div>
            <div class="course-name">${course.name}</div>
            <div class="course-info">👥 ${students.length} students</div>
            <div class="course-info">📅 ${course.schedule}</div>
            <div class="course-info">📍 ${course.location}</div>
            <div style="margin-top: var(--space-16);">
              <button class="btn btn-primary btn-full" onclick="event.stopPropagation(); showMarkAttendanceModal('${course.id}');">
                ✓ Mark Attendance
              </button>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderInstructorReports() {
  const content = document.getElementById('instructorContent');
  const user = appState.currentUser;
  const courses = getInstructorCourses(user.id);

  document.getElementById('instructorPageTitle').textContent = 'Reports & Analytics';

  content.innerHTML = `
    <div class="section-header">
      <h2 class="section-title">Course Reports</h2>
    </div>

    ${courses.map(course => {
      const students = getCourseStudents(course.id);
      const attendance = getCourseAttendance(course.id);
      const present = attendance.filter(a => a.status === 'Present').length;
      const absent = attendance.filter(a => a.status === 'Absent').length;
      const leave = attendance.filter(a => a.status === 'Leave').length;
      const courseAttendance = attendance.length > 0 ? Math.round((present / attendance.length) * 100) : 0;

      return `
        <div class="stat-card" style="margin-bottom: var(--space-24);">
          <div style="margin-bottom: var(--space-16);">
            <div class="course-code" style="margin-bottom: var(--space-8);">${course.code}</div>
            <h3 style="font-size: var(--font-size-xl); margin-bottom: var(--space-12);">${course.name}</h3>
          </div>

          <div class="stats-grid" style="margin-bottom: var(--space-16);">
            <div>
              <div class="stat-label">Total Students</div>
              <div class="stat-value" style="font-size: var(--font-size-2xl);">${students.length}</div>
            </div>
            <div>
              <div class="stat-label">Avg. Attendance</div>
              <div class="stat-value" style="font-size: var(--font-size-2xl);">${courseAttendance}%</div>
            </div>
            <div>
              <div class="stat-label">Present</div>
              <div class="stat-value" style="font-size: var(--font-size-2xl); color: var(--color-success);">${present}</div>
            </div>
            <div>
              <div class="stat-label">Absent</div>
              <div class="stat-value" style="font-size: var(--font-size-2xl); color: var(--color-error);">${absent}</div>
            </div>
          </div>

          <button class="btn btn-primary btn-sm" onclick="showInstructorCourseDetail('${course.id}')">
            View Details
          </button>
        </div>
      `;
    }).join('')}
  `;
}

function renderInstructorProfile() {
  const content = document.getElementById('instructorContent');
  const user = appState.currentUser;
  const courses = getInstructorCourses(user.id);
  let totalStudents = 0;

  courses.forEach(course => {
    totalStudents += getCourseStudents(course.id).length;
  });

  document.getElementById('instructorPageTitle').textContent = 'Profile';

  content.innerHTML = `
    <div class="stat-card">
      <div style="display: flex; gap: var(--space-24);">
        <div class="user-avatar" style="width: 80px; height: 80px; font-size: var(--font-size-3xl);">
          ${user.name.charAt(0)}
        </div>
        <div style="flex: 1;">
          <h2 style="font-size: var(--font-size-2xl); margin-bottom: var(--space-8);">${user.name}</h2>
          <div class="course-info" style="margin-bottom: var(--space-4);">🆔 Instructor ID: ${user.id}</div>
          <div class="course-info" style="margin-bottom: var(--space-4);">📧 Email: ${user.email}</div>
          <div class="course-info" style="margin-bottom: var(--space-4);">🏛️ Department: ${user.department}</div>
          <div class="course-info">📚 Teaching Courses: ${courses.length}</div>
        </div>
      </div>
    </div>

    <div class="stats-grid" style="margin-top: var(--space-24);">
      <div class="stat-card">
        <div class="stat-label">Courses Teaching</div>
        <div class="stat-value">${courses.length}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Students</div>
        <div class="stat-value">${totalStudents}</div>
      </div>
    </div>
  `;
}

// Modal Functions
function showCreateCourseModal() {
  const modalHTML = `
    <div class="modal-overlay" id="createCourseModal">
      <div class="modal">
        <div class="modal-header">
          <h2 class="modal-title">Create New Course</h2>
          <button class="btn-close" onclick="closeModal('createCourseModal')">×</button>
        </div>
        <form id="createCourseForm">
          <div class="form-group">
            <label class="form-label" for="courseCode">Course Code</label>
            <input type="text" id="courseCode" class="form-input" required placeholder="e.g., CS201">
          </div>
          <div class="form-group">
            <label class="form-label" for="courseName">Course Name</label>
            <input type="text" id="courseName" class="form-input" required placeholder="e.g., Algorithm Design">
          </div>
          <div class="form-group">
            <label class="form-label" for="courseSemester">Semester</label>
            <input type="text" id="courseSemester" class="form-input" required placeholder="e.g., Fall 2025">
          </div>
          <div class="form-group">
            <label class="form-label" for="courseSchedule">Schedule</label>
            <input type="text" id="courseSchedule" class="form-input" required placeholder="e.g., Mon/Wed 2:00 PM">
          </div>
          <div class="form-group">
            <label class="form-label" for="courseLocation">Location</label>
            <input type="text" id="courseLocation" class="form-input" required placeholder="e.g., Room 305">
          </div>
          <div class="form-group">
            <label class="form-label" for="courseCapacity">Capacity</label>
            <input type="number" id="courseCapacity" class="form-input" required placeholder="30" min="1">
          </div>
          <div class="modal-actions">
            <button type="button" class="btn btn-secondary" onclick="closeModal('createCourseModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Create Course</button>
          </div>
        </form>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', modalHTML);

  document.getElementById('createCourseForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const courseData = {
      code: document.getElementById('courseCode').value,
      name: document.getElementById('courseName').value,
      semester: document.getElementById('courseSemester').value,
      schedule: document.getElementById('courseSchedule').value,
      location: document.getElementById('courseLocation').value,
      capacity: document.getElementById('courseCapacity').value
    };

    if (appState.courses.find(c => c.code === courseData.code)) {
      showToast('Course code already exists!', 'error');
      return;
    }

    createCourse(courseData);
    showToast('Course created successfully!', 'success');
    closeModal('createCourseModal');
    renderInstructorCourses();
  });
}

function showMarkAttendanceModal(courseId) {
  const course = appState.courses.find(c => c.id === courseId);
  const students = getCourseStudents(courseId);
  const today = new Date().toISOString().split('T')[0];

  const modalHTML = `
    <div class="modal-overlay" id="markAttendanceModal">
      <div class="modal" style="max-width: 700px;">
        <div class="modal-header">
          <div>
            <h2 class="modal-title">Mark Attendance</h2>
            <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-top: var(--space-4);">
              ${course.code} - ${course.name}
            </div>
          </div>
          <button class="btn-close" onclick="closeModal('markAttendanceModal')">×</button>
        </div>
        
        <div class="form-group">
          <label class="form-label" for="attendanceDate">Date</label>
          <input type="date" id="attendanceDate" class="form-input" value="${today}" max="${today}">
        </div>

        <div style="margin-bottom: var(--space-16);">
          <div style="display: flex; gap: var(--space-8); margin-bottom: var(--space-12);">
            <button class="btn btn-sm btn-primary" onclick="markAllStudents('Present')">
              ✓ Mark All Present
            </button>
            <button class="btn btn-sm btn-secondary" onclick="markAllStudents('Absent')">
              ✗ Mark All Absent
            </button>
          </div>
        </div>

        <div class="checkbox-list" id="studentAttendanceList">
          ${students.map(student => {
            const existing = appState.attendance.find(
              a => a.courseId === courseId && a.studentId === student.id && a.date === today
            );
            const currentStatus = existing ? existing.status : 'Present';

            return `
              <div class="checkbox-item" style="display: flex; justify-content: space-between; padding: var(--space-12);">
                <div>
                  <div style="font-weight: var(--font-weight-medium);">${student.name}</div>
                  <div style="font-size: var(--font-size-xs); color: var(--color-text-secondary);">${student.id}</div>
                </div>
                <div style="display: flex; gap: var(--space-8);">
                  <label style="display: flex; align-items: center; gap: var(--space-4); cursor: pointer;">
                    <input type="radio" name="attendance_${student.id}" value="Present" ${currentStatus === 'Present' ? 'checked' : ''}>
                    <span style="font-size: var(--font-size-sm);">Present</span>
                  </label>
                  <label style="display: flex; align-items: center; gap: var(--space-4); cursor: pointer;">
                    <input type="radio" name="attendance_${student.id}" value="Absent" ${currentStatus === 'Absent' ? 'checked' : ''}>
                    <span style="font-size: var(--font-size-sm);">Absent</span>
                  </label>
                  <label style="display: flex; align-items: center; gap: var(--space-4); cursor: pointer;">
                    <input type="radio" name="attendance_${student.id}" value="Leave" ${currentStatus === 'Leave' ? 'checked' : ''}>
                    <span style="font-size: var(--font-size-sm);">Leave</span>
                  </label>
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <div class="modal-actions">
          <button type="button" class="btn btn-secondary" onclick="closeModal('markAttendanceModal')">Cancel</button>
          <button type="button" class="btn btn-primary" onclick="saveAttendance('${courseId}')">
            Save Attendance
          </button>
        </div>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', modalHTML);
}

function markAllStudents(status) {
  document.querySelectorAll('[name^="attendance_"]').forEach(radio => {
    if (radio.value === status) {
      radio.checked = true;
    }
  });
}

function saveAttendance(courseId) {
  const date = document.getElementById('attendanceDate').value;
  const students = getCourseStudents(courseId);

  students.forEach(student => {
    const selectedRadio = document.querySelector(`input[name="attendance_${student.id}"]:checked`);
    if (selectedRadio) {
      markAttendance(courseId, student.id, date, selectedRadio.value);
    }
  });

  showToast('Attendance saved successfully!', 'success');
  closeModal('markAttendanceModal');
  renderInstructorDashboard();
}

function deleteCourseConfirm(courseId) {
  const course = appState.courses.find(c => c.id === courseId);
  if (confirm(`Are you sure you want to delete ${course.code} - ${course.name}?\n\nThis will also delete all associated attendance records.`)) {
    deleteCourse(courseId);
    showToast('Course deleted successfully!', 'success');
    renderInstructorDashboard();
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.remove();
  }
}

// Toast notifications
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
  initializeSampleData();

  const authForm = document.getElementById('authForm');
  const authToggleLink = document.getElementById('authToggleLink');
  let isLoginMode = true;

  authToggleLink.addEventListener('click', () => {
    isLoginMode = !isLoginMode;
    const registerFields = document.getElementById('registerFields');
    const authTitle = document.getElementById('authTitle');
    const authSubtitle = document.getElementById('authSubtitle');
    const authSubmitBtn = document.getElementById('authSubmitBtn');
    const authToggleText = document.getElementById('authToggleText');

    if (isLoginMode) {
      registerFields.classList.add('hidden');
      authTitle.textContent = 'Sign In';
      authSubtitle.textContent = 'Access your attendance dashboard';
      authSubmitBtn.textContent = 'Sign In';
      authToggleText.textContent = "Don't have an account?";
      authToggleLink.textContent = 'Register';
    } else {
      registerFields.classList.remove('hidden');
      authTitle.textContent = 'Register';
      authSubtitle.textContent = 'Create your account';
      authSubmitBtn.textContent = 'Register';
      authToggleText.textContent = 'Already have an account?';
      authToggleLink.textContent = 'Sign In';
    }
  });

  authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const email = document.getElementById('authEmail').value;
    const password = document.getElementById('authPassword').value;
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');

    emailError.classList.add('hidden');
    passwordError.classList.add('hidden');

    if (isLoginMode) {
      const result = login(email, password);
      if (result.success) {
        showDashboard(result.user.role);
      } else {
        emailError.textContent = result.message;
        emailError.classList.remove('hidden');
      }
    } else {
      const name = document.getElementById('registerName').value;
      const role = document.getElementById('registerRole').value;
      const department = document.getElementById('registerDept').value;

      if (!name) {
        emailError.textContent = 'Please enter your full name';
        emailError.classList.remove('hidden');
        return;
      }

      const result = register(name, email, password, role, department);
      if (result.success) {
        showToast('Registration successful!', 'success');
        showDashboard(result.user.role);
      } else {
        emailError.textContent = result.message;
        emailError.classList.remove('hidden');
      }
    }
  });

  // Student navigation
  document.querySelectorAll('#studentView .nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      document.querySelectorAll('#studentView .nav-item').forEach(i => i.classList.remove('active'));
      e.target.classList.add('active');

      const view = e.target.dataset.view;
      switch(view) {
        case 'studentDashboard':
          renderStudentDashboard();
          break;
        case 'studentCourses':
          renderStudentCourses();
          break;
        case 'studentAttendance':
          renderStudentAttendance();
          break;
        case 'studentProfile':
          renderStudentProfile();
          break;
      }
    });
  });

  // Instructor navigation
  document.querySelectorAll('#instructorView .nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      document.querySelectorAll('#instructorView .nav-item').forEach(i => i.classList.remove('active'));
      e.target.classList.add('active');

      const view = e.target.dataset.view;
      switch(view) {
        case 'instructorDashboard':
          renderInstructorDashboard();
          break;
        case 'instructorCourses':
          renderInstructorCourses();
          break;
        case 'instructorAttendance':
          renderInstructorAttendance();
          break;
        case 'instructorReports':
          renderInstructorReports();
          break;
        case 'instructorProfile':
          renderInstructorProfile();
          break;
      }
    });
  });

  // Logout buttons
  document.getElementById('studentLogoutBtn').addEventListener('click', logout);
  document.getElementById('instructorLogoutBtn').addEventListener('click', logout);
});